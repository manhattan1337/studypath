const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_PROMPT = `Ты — профессиональный AI-консультант по поступлению за границу для школьников (14–18 лет), специализирующийся на подготовке к IELTS, SAT и программе FLEX.

Твоя задача — создать максимально персонализированный и реалистичный план.

ЭТАП 1 — Собери данные, задавая вопросы СТРОГО ПО ОДНОМУ (не задавай несколько вопросов сразу):

Вопрос 1: Возраст и класс
Вопрос 2: Страна (где сейчас учится)
Вопрос 3: Уровень английского (A1–C1 или баллы IELTS если есть)
Вопрос 4: Цель — FLEX (обмен), поступление в США или поступление в Европу
Вопрос 5: Срок (через сколько месяцев/лет планирует поступать)
Вопрос 6: Время в день на подготовку (часы)
Вопрос 7: Достижения (олимпиады, проекты, волонтёрство — или их отсутствие)

После получения всех 7 ответов создай полный план с такими разделами:

📋 ПЛАН ПОДГОТОВКИ — конкретный план по неделям/месяцам для IELTS/SAT/FLEX

📅 РАСПИСАНИЕ — ежедневные задачи с конкретным временем, еженедельные цели, этапы с дедлайнами

📚 КАК УЧИТЬ — что изучать (конкретные навыки), конкретные ресурсы и действия, типичные ошибки

🏆 ACTIVITIES — какие активности развивать и как оформить для заявки

🎯 СТРАТЕГИЯ ПОСТУПЛЕНИЯ — какие экзамены сдавать, когда, дедлайны

⚡ ЧЕСТНАЯ ОЦЕНКА — реалистична ли цель, что критически важно улучшить

Правила:
- Отвечай только по-русски
- Никаких общих фраз — только конкретика под этого пользователя
- Стиль: личный наставник, прямо и по делу
- Используй emoji для структуры`;

// Chat endpoint — uses Google Gemini (FREE)
app.post("/api/chat", async (req, res) => {
  const { messages } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: "GEMINI_API_KEY not set on server" });
  }

  // Convert history to Gemini format
  // Gemini uses "user" / "model" roles
  // First message: inject system prompt as first user turn
  const geminiHistory = messages.map((m, i) => ({
    role: m.role === "user" ? "user" : "model",
    parts: [{ text: m.content }],
  }));

  // Prepend system as a user/model exchange (Gemini doesn't have system role)
  const fullContents = [
    { role: "user", parts: [{ text: SYSTEM_PROMPT + "\n\nПоприветствуй пользователя и задай первый вопрос." }] },
    { role: "model", parts: [{ text: "Привет! 👋 Я твой личный AI-консультант по поступлению за рубеж.\n\nПомогу составить **конкретный план** подготовки к IELTS, SAT или программе FLEX — под тебя, без воды.\n\nНачнём! Сколько тебе лет и в каком ты классе?" }] },
    ...geminiHistory,
  ];

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: fullContents }),
      }
    );

    const data = await response.json();

    if (data.error) {
      return res.status(400).json({ error: data.error.message });
    }

    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || "Не удалось получить ответ.";
    res.json({ reply: text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Ошибка сервера" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`✅ StudyPath server running on port ${PORT}`));
