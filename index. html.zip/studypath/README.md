# 🎓 StudyPath — AI Консультант по поступлению

Бесплатный AI-сайт для школьников. Составляет персональный план подготовки к IELTS, SAT, FLEX.

---

## 📁 Структура проекта

```
studypath/
├── server.js        ← бэкенд (Node.js + Express)
├── package.json     ← зависимости
└── public/
    └── index.html   ← фронтенд (весь сайт)
```

---

## 🚀 Деплой за 5 минут (бесплатно на Render.com)

### Шаг 1 — Получи бесплатный Gemini API ключ
1. Зайди на https://aistudio.google.com
2. Войди через Google аккаунт
3. Нажми **"Get API key"** → **"Create API key"**
4. Скопируй ключ (выглядит как `AIzaSy...`)

### Шаг 2 — Залей код на GitHub
1. Зайди на https://github.com → создай аккаунт если нет
2. Нажми **"New repository"** → назови `studypath`
3. Загрузи все файлы проекта (перетащи папку)

### Шаг 3 — Задеплой на Render.com
1. Зайди на https://render.com → **Sign up with GitHub**
2. Нажми **"New +"** → **"Web Service"**
3. Выбери свой репозиторий `studypath`
4. Настройки:
   - **Environment:** `Node`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
5. Нажми **"Advanced"** → **"Add Environment Variable"**:
   - Key: `GEMINI_API_KEY`
   - Value: вставь свой ключ `AIzaSy...`
6. Нажми **"Create Web Service"**

✅ Через 2-3 минуты сайт будет доступен по адресу типа `https://studypath.onrender.com`

---

## 💻 Запуск локально (для тестирования)

```bash
# 1. Установи Node.js с nodejs.org если не установлен

# 2. Перейди в папку проекта
cd studypath

# 3. Установи зависимости
npm install

# 4. Создай файл .env
echo "GEMINI_API_KEY=твой_ключ_сюда" > .env

# 5. Запусти
node server.js

# Открой браузер: http://localhost:3000
```

---

## 💰 Стоимость

| Что | Цена |
|-----|------|
| Gemini API | **Бесплатно** (1500 запросов/день) |
| Render.com хостинг | **Бесплатно** |
| GitHub | **Бесплатно** |
| **Итого** | **$0** |

---

## 📈 Когда вырастешь (платные апгрейды)

- Больше пользователей → Railway.app ($5/мес) или VPS
- Лучший AI → Anthropic Claude API
- Своё доменное имя → ~$10/год на namecheap.com
